# prototype_lobby (hypixel.net) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Thu, 7 Aug 2025 11:54:05 +1000` (Timestamp: `1754531645389`)
- **Captured By**: `Swofty`

## Server
- **IP**: `hypixel.net`
- **Capacity**: `27318/200000`
- **Brand**: `Hypixel BungeeCord (2025.7.29.1) <- Hygot 2025.8.4.1`
- **MOTD**: `                §aHypixel Network §c[1.8-1.21]   §2§lSB 0.23.3 §a§lFORAGING PATCH §8§l- §e§lSUMMER EVENT`
- **Version**: `Requires MC 1.8 / 1.21`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `172.65.196.232`
- **Port**: `25565`
- **Session ID**: `73b6fe0f-43df-4754-a3a6-6ab56149c10e`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
