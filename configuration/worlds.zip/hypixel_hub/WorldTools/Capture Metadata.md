# test (mc.hypixel.net) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 10 Mar 2024 12:54:06 GMT` (Timestamp: `1710075246700`)
- **Captured By**: `Swofty`

## Server
- **IP**: `mc.hypixel.net`
- **Capacity**: `40533/200000`
- **Brand**: `Hypixel BungeeCord (2024.2.26.1) <- vanilla`
- **MOTD**: `                §aHypixel Network §c[1.8-1.20]      §d§lSKYBLOCK 0.19.11 §7| §6§lTNT GAMES UPDATE`
- **Version**: `Requires MC 1.8 / 1.20`
- **Protocol Version**: `765`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `209.222.114.37`
- **Port**: `25565`
- **Session ID**: `fb9a64b9-a7fe-457c-ad70-215eb9fae733`

This file was created by [WorldTools 1.2.4](https://github.com/Avanatiker/WorldTools/)
